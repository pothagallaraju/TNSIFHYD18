package com.day1;

public class program20 {

	public static void main(String[] args) {
				        // Initialize an array of integers 
		        int[] array = {2, 4, 6, 8, 10}; 
		        
		        // Calculate the sum of elements in the array 
		        int sum = 0; 
		        for (int num : array) { 
		            sum += num; 
		        } 
		        
		        // Print the sum of elements 
		        System.out.println("Sum of elements in the array: " + sum); 
		    } 
		}

		
